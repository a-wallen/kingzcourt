package com.example.kingzcourt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
